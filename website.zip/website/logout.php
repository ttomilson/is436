<!DOCTYPE html>
<html lang="en">
<head>
	<title> Logout </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<link rel ="stylesheet" type="text/css" href="form.css" title="style" />
</head>

<body>
	<h1> Tawle Event Planning </h1>

<div class="loginbox">

<h2> You are now logged out <br /> Click <a href="https://swe.umbc.edu/~there2/is436/website/login.php"> here</a> to return to login</h2>

</div>

</form>
</body>
</html>
